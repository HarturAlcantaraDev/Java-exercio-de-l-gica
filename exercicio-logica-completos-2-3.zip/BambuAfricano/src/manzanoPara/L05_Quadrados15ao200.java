package manzanoPara;

public class L05_Quadrados15ao200 {

	public static void main(String[] args) {
		
		int quadrado;
		for (short contadora = 15; contadora <= 200; contadora++) {
			quadrado = contadora*contadora;
			System.out.println("O quadrado de "+contadora+" �: "+quadrado);
		}
	}

}
