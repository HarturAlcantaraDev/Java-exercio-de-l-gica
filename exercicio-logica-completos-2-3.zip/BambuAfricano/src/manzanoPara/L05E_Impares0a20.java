package manzanoPara;

public class L05E_Impares0a20 {

	public static void main(String[] args) {
		
		for (byte contadora = 0; contadora <= 20; contadora++) {
			if (contadora%2==1) {
				System.out.println(contadora);
			}
		}

	}

}
