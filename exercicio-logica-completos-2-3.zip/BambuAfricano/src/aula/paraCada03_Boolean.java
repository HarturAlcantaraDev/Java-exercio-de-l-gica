package aula;

public class paraCada03_Boolean {

	public static void main(String[] args) {
		
		Boolean [] escolhas = {true, false, false, false, true, false};
		
		for (Boolean i : escolhas) {
			System.out.println(i);
		}

	}

}
