package aula;

public class ParaCada02_Nomes {

	public static void main(String[] args) {
		
		String [] nomes = {"Alvaro", "Isaque", "Felipe", "Lucas", "Gutierre", "Freitas"};

		for (String i : nomes) {
			System.out.println(i);
		}
	}

}
