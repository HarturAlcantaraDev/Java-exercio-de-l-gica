package aula;

public class CriandoMetodo {

	static void myMethod() {
		System.out.println("Eu posso ser executado");
	}
	
	public static void main(String[] args) {
		myMethod();
	}

}
