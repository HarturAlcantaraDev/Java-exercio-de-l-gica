package aula;

public class Parametros2 {

	public static void meuMetodo(String nome) {
		System.out.println(nome + "Refsnes");
	}
	
	public static void main(String[] args) {
		meuMetodo("Alvaro ");
		meuMetodo("Jailson ");
		meuMetodo("Isaque ");
	}

}
