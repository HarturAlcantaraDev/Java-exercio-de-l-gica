package aula;

public class ObjetoCriar {

	int x = 5;
	
	public static void main(String[] args) {
		
		ObjetoCriar meuObjeto = new ObjetoCriar();
		System.out.println(meuObjeto.x);
		

	}

}
