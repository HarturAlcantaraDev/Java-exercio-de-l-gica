package aula;

public class TesteCarro {

	public static void main(String[] args) {

		Carro carro01 = new Carro();
		System.out.println(carro01.modelo);
		System.out.println(carro01.motor);
		System.out.println(carro01.cor);
		
	}

}
