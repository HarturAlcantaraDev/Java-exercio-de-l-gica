package aula;

public class JavaMathExemplo {

	public static void main(String[] args) {
		
		int numero = 10;
		int numero1 = 4;
		
		System.out.println(Math.max(numero, numero1));
		System.out.println(Math.min(numero, numero1));
		System.out.println(Math.sqrt(144));
		System.out.println(Math.abs(-25.4));
		System.out.println(Math.random());

	}

}
