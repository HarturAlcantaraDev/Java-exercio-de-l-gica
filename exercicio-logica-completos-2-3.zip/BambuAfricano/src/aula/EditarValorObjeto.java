package aula;

public class EditarValorObjeto {

	int x = 10;
	
	public static void main(String[] args) {

		EditarValorObjeto editar = new EditarValorObjeto();
		editar.x = 25;
		System.out.println(editar.x);
		
	}

}
