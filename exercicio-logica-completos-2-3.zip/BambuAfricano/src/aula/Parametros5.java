package aula;

public class Parametros5 {
	
	public static int meuMetodo(int x) {
		return 5+x;
	}

	public static void main(String[] args) {
		System.out.println(meuMetodo(3));
	}

}
