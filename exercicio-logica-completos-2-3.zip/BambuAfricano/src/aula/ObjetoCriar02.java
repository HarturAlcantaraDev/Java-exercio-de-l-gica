package aula;

public class ObjetoCriar02 {

	int x = 5;
	
	public static void main(String[] args) {
		ObjetoCriar02 objeto01 = new ObjetoCriar02();
		ObjetoCriar02 objeto02 = new ObjetoCriar02();
		System.out.println(objeto01.x);
		System.out.println(objeto02.x);
		
	}

}
