package aula;

public class Matriz {

	public static void main(String[] args) {
		
		int [][] numbers = {{1,2,3,4}, {5,6,7}};
		
		for (byte i = 0; i < numbers.length; i++) {
			for (byte j = 0; j < numbers[i].length; j++) {
				System.out.println(numbers[i][j]);
			}
		}

	}

}
