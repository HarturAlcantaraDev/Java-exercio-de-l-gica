package aula;

public class Carro {
	
	String modelo = "Ford Focus Fast Back";
	String motor = "1.0";
	String cor = "Preto";

}
