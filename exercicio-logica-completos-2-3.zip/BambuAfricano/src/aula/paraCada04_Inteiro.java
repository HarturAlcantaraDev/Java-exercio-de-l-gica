package aula;

public class paraCada04_Inteiro {

	public static void main(String[] args) {
		
		int [] numeros = {7, 5, 3, 41502, 915, 10205, 461};
		
		for (int i : numeros) {
			System.out.println(i);
		}

	}

}
