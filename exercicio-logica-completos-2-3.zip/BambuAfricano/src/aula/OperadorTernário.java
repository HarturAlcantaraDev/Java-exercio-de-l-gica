package aula;

public class OperadorTern�rio {

	public static void main(String[] args) {
		
		
		int numero = 10;
		
		System.out.println(numero);
	
		

	}

}
