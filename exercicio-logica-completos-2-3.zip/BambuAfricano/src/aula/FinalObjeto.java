package aula;

public class FinalObjeto {

	final int x = 10;
	
	public static void main(String[] args) {

		FinalObjeto editar = new FinalObjeto();
//		editar.x = 25;
		System.out.println(editar.x);
		
	}

}
