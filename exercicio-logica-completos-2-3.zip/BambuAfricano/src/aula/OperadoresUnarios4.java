package aula;

public class OperadoresUnarios4 {
	
	public static void main(String[]args) {
		
		int a = 10;
		int b = 5;
		
		System.out.println("A adi�o �: " + (a+b));
		System.out.println("A adi�o �: " + (a-b));
		System.out.println("A adi�o �: " + (a*b));
		System.out.println("A adi�o �: " + (a/b));
		System.out.println("A adi�o �: " + (a%b));
		System.out.println(10<<2);
		System.out.println(10<<4);
		System.out.println(10<<7);
		System.out.println(10>>2);
	}

}
