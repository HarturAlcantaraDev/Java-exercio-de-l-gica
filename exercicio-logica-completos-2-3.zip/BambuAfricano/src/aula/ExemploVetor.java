package aula;

public class ExemploVetor {

	public static void main(String[] args) {
		
		int[] numeros = {10, 20, 30, 40, 50, 60, 70};
	
		System.out.println("O n�mero de posi��es ocupadas �: "+numeros.length);
		
		for (byte i = 0; i <= 6; i++) {
			System.out.println(numeros[i]);
		}
	}

}
