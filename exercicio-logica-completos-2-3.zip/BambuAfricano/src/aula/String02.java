package aula;

public class String02 {

	public static void main(String[]args) {
		
		
		String nome = "Alvaro";
		
		System.out.println(nome);
		
		System.out.println(nome.length());
		
		System.out.println(nome.toUpperCase());
		
		System.out.println(nome.toLowerCase());
		
		String frase = "Adoro Step by Step";
		
		System.out.println(frase.indexOf("Step"));
		
		System.out.println(nome+" "+frase);
		
		String txt = "We are the so-called \"Vikings\"from the north";
		
		System.out.println(txt);
		
		String txt2 = "It's alright";
		
		System.out.println(txt2);
		
	}
	
}
