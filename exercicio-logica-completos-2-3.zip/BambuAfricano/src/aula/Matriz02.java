package aula;

public class Matriz02 {

	public static void main(String[] args) {
		
		int [][] numeros = {{5, 7, 101, 243}, {-9, -465, 83}};
		System.out.println(numeros[1][2]);

	}

}
