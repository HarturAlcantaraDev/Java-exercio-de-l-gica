package aula;

public class TiposVariaveis {

	public static void main(String[]args) {
		byte numero = 127;
		byte numero1 = -128;
		
		short numero2 = 32767;
		short numero3 = -32768;
		
		int numero4=2147483647;
		int numero5=-2147483648;
	
		long numero6= 9223372036854775807l;
		long numero7 = -9223372036854775808l;
		
		float numero8= 9223372036854775807f;
		float numero9 = -9223372036854775808f;
		
		double numero10 = 9223372036854775807d;
		double numero11 = -9223372036854775808d;
		
		
		
		System.out.println("N�mero: "+numero);
		System.out.println("N�mero1: "+numero1);
		System.out.println("N�mero2: "+numero2);
		System.out.println("N�mero3: "+numero3);
		System.out.println("N�mero4: "+numero4);
		System.out.println("N�mero5: "+numero5);
		System.out.println("N�mero6: "+numero6);
		System.out.println("N�mero7: "+numero7);
		System.out.println("N�mero8: "+numero8);
		System.out.println("N�mero9: "+numero9);
		System.out.println("N�mero10: "+numero10);
		System.out.println("N�mero11: "+numero11);
	}
	
}
