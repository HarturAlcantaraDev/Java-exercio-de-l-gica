package aula;

public class Enquanto {

	public static void main(String[] args) {
		
		byte contadora = 11;
		
		while (contadora<=10) {
			System.out.println("Bambu Africano" + " e a contadora �: "+ contadora);
			contadora++;
		}
	
	}

}
