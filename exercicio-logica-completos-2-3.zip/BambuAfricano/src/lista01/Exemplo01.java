package lista01;

public class Exemplo01 {
	
	public static void main(String[]args) {
		System.out.println("Ol� world");
	}
}
