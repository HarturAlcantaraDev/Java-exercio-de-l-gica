package lista01;
import java.util.Scanner;


public class exemplo02 {
	
	public static void ensinando() {
		
	}

	public static void main(String[]args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Digite um valor: ");
		int valor = sc.nextInt();
		System.out.println(valor);
		sc.close();
	}
}
